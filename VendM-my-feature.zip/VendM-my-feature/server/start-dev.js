import { spawn } from "child_process";

const childOptions = { stdio: "inherit", shell: true, env: process.env };

const backend = spawn("npm", ["run", "dev:server"], childOptions);
const frontend = spawn("npm", ["run", "dev"], childOptions);

const cleanup = () => {
  if (!backend.killed) backend.kill();
  if (!frontend.killed) frontend.kill();
  process.exit();
};

process.on("SIGINT", cleanup);
process.on("SIGTERM", cleanup);
process.on("exit", cleanup);

backend.on("exit", (code) => {
  if (code !== 0) {
    console.error(`Backend exited with code ${code}`);
    cleanup();
  }
});

frontend.on("exit", (code) => {
  if (code !== 0) {
    console.error(`Frontend exited with code ${code}`);
    cleanup();
  }
});
